﻿using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FishingNet
{
    public class Net
    {
        
        public Net(string material, int capacity)
        {
            Material = material;
            Capacity = capacity;
            fishList = new List<Fish>();
        }
        public string Material  { get; set; }

        public int Capacity { get; set; }

        public List<Fish> fishList { get; set; }

        public int Count => fishList.Count;

         public string AddFish(Fish fish)
         {
            if(string.IsNullOrWhiteSpace(fish.FishType) || fish.Length <= 0 || fish.Weight <= 0)
            {
                return "Invalid fish.";
            }
            if(Count >= Capacity)
            {
                return "Fishing net is full.";
            }
            fishList.Add(fish);
            return $"Successfully added {fish.FishType} to the fishing net."; 
        }
        public bool ReleaseFish(double weight)
        {
            
            List<Fish> removed = new List<Fish>();
            var toRemove = fishList.FirstOrDefault(x => x.Weight == weight);
            if(toRemove != null)
            {
                removed = fishList.Where(x => x.Weight != weight).ToList();
                fishList = removed;
                return true;
            }
            return false;
        }

         public Fish GetFish(string fishType)
        {
            var getFish = fishList.Where(x => x.FishType == fishType).FirstOrDefault(); 
            return getFish;
        }

        public Fish GetBiggestFish()
        {
            var longest = fishList.OrderByDescending(x => x.Length).FirstOrDefault();
            return longest;
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            if(fishList.Count > 0)
            {
                sb.AppendLine($"Into the {Material}:");
                foreach(var fish in fishList.OrderByDescending(x => x.Length))
                {
                    sb.AppendLine(fish.ToString());
                }
                return sb.ToString().TrimEnd();
            }
            return null;
        }
    }
}

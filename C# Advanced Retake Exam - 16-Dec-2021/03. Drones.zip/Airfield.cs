﻿using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drones
{
    public class Airfield
    {
        public Airfield(string name, int capacity, double landingStrip)
        {
            Name = name;
            Capacity = capacity;
            LandingStrip = landingStrip;
            Drones = new List<Drone>();
        }
        public string Name { get; set; }

        public int Capacity { get; set; }

        public double LandingStrip { get; set; }

        public List<Drone> Drones { get; set; }

        public int Count => Drones.Count;

        public string AddDrone(Drone drone)
        {
            if(string.IsNullOrEmpty(drone.Name) || string.IsNullOrEmpty(drone.Brand) || drone.Range < 5 || drone.Range > 15)
            {
                return "Invalid drone.";
            }
            if(Count >= Capacity)
            {
                return "Airfield is full.";
            }
            Drones.Add(drone);
            return $"Successfully added {drone.Name} to the airfield.";
        }

        public bool RemoveDrone(string name)
        {
            var toRemove = Drones.Where(x => x.Name == name).ToList();  
            if(toRemove.Count > 0)
            {
                var current = Drones.Where(x => x.Name != name).ToList();
                Drones = current;
                return true;
            }
            return false;
        }
        public int RemoveDroneByBrand(string brand)
        {
            var removed = Drones.Where(x => x.Brand == brand).ToList();
            if(removed.Count > 0)
            {
                var current = Drones.Where(x => x.Brand != brand).ToList();
                Drones = current;
                return removed.Count;
            }
            return 0;
        }
        public Drone FlyDrone(string name)
        {

            for (int i = 0; i < Drones.Count; i++)
            {
                if (Drones[i].Name == name)
                {
                    Drones[i].Available = false;
                    return Drones[i];
                }
                
            }

            return null;
        }
        public List<Drone> FlyDronesByRange(int range)
        {
            List<Drone> flyDrones = new List<Drone>();
            List<Drone> current = new List<Drone>();
            flyDrones = Drones.Where(x =>x.Range >= range).ToList();
            current = Drones.Where(x => x.Range < range).ToList();
            Drones.Clear();
            Drones = current;
            return flyDrones;
        }
        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Drones available at {Name}:");
            foreach (var drone in Drones.Where(x => x.Available == true))
            {
                sb.AppendLine($"{drone}");

            }
            return sb.ToString().TrimEnd();
        }
    }
}

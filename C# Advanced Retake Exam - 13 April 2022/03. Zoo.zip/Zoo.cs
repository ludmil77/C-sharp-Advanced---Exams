﻿using System.Collections.Generic;
using System.Linq;

namespace Zoo
{
    public class Zoo
    {
        private List<Animal> Animals;
        public Zoo(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            Animals = new List<Animal>();
        }
        public string Name { get; set; }

        public int Capacity { get; set; }

        public int Count => Animals.Count;

        public string AddAnimal(Animal animal)
        {
            if(string.IsNullOrWhiteSpace(animal.Species))
            {
                return $"Invalid animal species.";
            }
            if(animal.Diet != "herbivore" && animal.Diet != "carnivore")
            {
                return $"Invalid animal diet.";
            }
            if(Count >= Capacity)
            {
                return $"The zoo is full.";
            }
            Animals.Add(animal);
            return $"Successfully added {animal.Species} to the zoo.";
        }

        public int RemoveAnimals(string species)
        {
            List<Animal> toRemove = new List<Animal>();
            List<Animal> removed = new List<Animal>();
            toRemove = Animals.Where(x => x.Species == species).ToList();
            if(toRemove.Count > 0)
            {
                removed = Animals.Where(x =>x.Species != species).ToList();
                Animals = removed.ToList();
                return toRemove.Count;
            }
            return 0;
        }
        public List<Animal> GetAnimalsByDiet(string diet)
        {
            List<Animal> byDiet = new List<Animal>();
            byDiet = Animals.Where(x => x.Diet == diet).ToList();
            return byDiet;
        }
        public Animal GetAnimalByWeight(double weight)
        {
            
            var byWeight = Animals.Where(x =>x.Weight == weight).FirstOrDefault();
            return byWeight;
        }
        public string GetAnimalCountByLength(double minimumLength, double maximumLength)
        {
            List<Animal> byLength = new List<Animal>();
            byLength = Animals.Where(x => x.Length >= minimumLength && x.Length <= maximumLength).ToList();
            return $"There are {byLength.Count} animals with a length between {minimumLength} and {maximumLength} meters.";
        }
    }
}

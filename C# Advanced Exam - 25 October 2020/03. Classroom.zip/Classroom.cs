﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ClassroomProject
{
    public class Classroom
    {
         private List<Student> students;

        public Classroom(int capacity)
        {
            Capacity = capacity;
            students = new List<Student>();
        }
        public int Capacity { get; set; }

         public int Count => students.Count;    

        public string RegisterStudent(Student student)
        {
            if(Count < Capacity)
            {
                students.Add(student);
                return $"Added student {student.FirstName} {student.LastName}";
            }
            else
            {
                return $"No seats in the classroom";
            }
        }
        public string DismissStudent(string firstName, string lastName)
        {
            Student toRemove = students.FirstOrDefault(x => x.FirstName == firstName && x.LastName == lastName);
            if(toRemove != null)
            {
                students.Remove(toRemove);
                return $"Dismissed student {firstName} {lastName}";
            }
            return $"Student not found";
        }

        public string GetSubjectInfo(string subject)
        {
            StringBuilder sb = new StringBuilder();
            List<Student> withSubject = new List<Student>();
             withSubject = students.FindAll(x => x.Subject == subject).ToList();
            if(withSubject.Count == 0)
            {
                return $"No students enrolled for the subject";
            }
            sb.AppendLine($"Subject: {subject}");
            sb.AppendLine($"Students:");
            foreach(var student in withSubject)
            {
                sb.AppendLine($"{student.FirstName} {student.LastName}");
            }
            return sb.ToString().TrimEnd();
        }

        public int GetStudentsCount() => students.Count;

        public Student GetStudent(string firstName, string lastName) => students.FirstOrDefault(x => x.FirstName == firstName && x.LastName == lastName);


    }
}

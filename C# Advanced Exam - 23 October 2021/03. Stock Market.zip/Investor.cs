﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Transactions;

namespace StockMarket
{
    public class Investor
    {
        private List<Stock> Portfolio;
        public Investor(string fullName, string emailAddress, decimal moneyToInvest, string brokerName)
        {
            FullName = fullName;
            EmailAddress = emailAddress;
            MoneyToInvest = moneyToInvest;
            BrokerName = brokerName;
            Portfolio = new List<Stock>();
        }
        public string FullName { get; set; }

        public string EmailAddress { get; set; }

        public decimal MoneyToInvest { get; set; }

        public string BrokerName { get; set; }

        public int Count => Portfolio.Count;

        public void BuyStock(Stock stock)
        {
            if(stock.MarketCapitalization > 10000 && MoneyToInvest >= stock.PricePerShare)
            {
                Portfolio.Add(stock);
                MoneyToInvest -= stock.PricePerShare;
            }
        }
        public string SellStock(string companyName, decimal sellPrice)
        {
            var currennt = new List<Stock>();
            var newCurrennt = new List<Stock>();
            currennt = Portfolio.Where(x => x.CompanyName == companyName ).ToList();
            if(currennt.Count == 0)
            {
                return $"{companyName} does not exist.";
            }
            for(int i = 0; i < currennt.Count; i++)
            {
                if(currennt[i].PricePerShare > sellPrice)
                {
                    return $"Cannot sell {companyName}.";
                }
            }
            MoneyToInvest += sellPrice;
            newCurrennt = Portfolio.Where(x => x.CompanyName != companyName).ToList();
            Portfolio = newCurrennt.ToList();
            return $"{companyName} was sold.";
        }
        public Stock FindStock(string companyName)
        {
            
            var find = Portfolio.Where(x => x.CompanyName == companyName).FirstOrDefault();
            if(find != null)
            {
                return find;
            }
            return null;
        }
        public Stock FindBiggestCompany()
        {
            if(Portfolio.Count > 0)
            {
                var biggest = Portfolio.OrderByDescending(x => x.MarketCapitalization).FirstOrDefault();
                return biggest;
            }
            return null;
            
        }
        public string InvestorInformation()
        {
            if (Portfolio.Count > 0)
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine($"The investor {FullName} with a broker {BrokerName} has stocks:");
                foreach(var x in Portfolio)
                {
                    sb.AppendLine($"{x}");
                }
                return sb.ToString().TrimEnd();
            }
            return null;
        }
    }
}
